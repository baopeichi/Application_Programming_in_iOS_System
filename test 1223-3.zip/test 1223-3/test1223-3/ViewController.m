//
//  ViewController.m
//  test1223-3
//
//  Created by E420_53 on 2022/12/23.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

-(IBAction)long1:(UILongPressGestureRecognizer*)sender{
    _view1.frame=CGRectMake(_view1.frame.origin.x, _view1.frame.origin.y, _view1.frame.size.width+30, _view1.frame.size.height+30);
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
