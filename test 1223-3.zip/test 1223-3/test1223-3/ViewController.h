//
//  ViewController.h
//  test1223-3
//
//  Created by E420_53 on 2022/12/23.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property(weak,nonatomic)IBOutlet UIView *view1;

@end

